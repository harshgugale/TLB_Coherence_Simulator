/*
 * Copyright 2002-2019 Intel Corporation.
 * 
 * This software is provided to you as Sample Source Code as defined in the accompanying
 * End User License Agreement for the Intel(R) Software Development Products ("Agreement")
 * section 1.L.
 * 
 * This software and the related documents are provided as is, with no express or implied
 * warranties, other than those that are expressly stated in the License.
 */


/*! @file
 *  An example of SMC application. 
 */
#include "smc_util.h"
#include "../Utils/sys_memory.h"

/*!
 * Exit with the specified error message
 */
static void Abort(string msg)
{
    cerr << msg << endl;
    exit(1);
}


/*!
 * The main procedure of the application.
 */
int main(int argc, char *argv[])
{
    cerr << "SMC in the image of the application" << endl;

    // buffer to move foo/bar routines into and execute
    static char staticBuffer[PI_FUNC::MAX_SIZE];
    // Set read-write-execute protection for the buffer 
    size_t pageSize = GetPageSize();
    char * firstPage = (char *)(((size_t)staticBuffer) & ~(pageSize - 1));
    char * endPage = (char *)(((size_t)staticBuffer + sizeof(staticBuffer) + pageSize - 1) & ~(pageSize - 1));
    if (!MemProtect(firstPage, endPage - firstPage, MEM_READ_WRITE_EXEC)) {Abort("MemProtect failed");}

    for (int i = 0; i < 3; ++i)
    {
        FOO_FUNC fooFunc;
        fooFunc.Copy(staticBuffer).Execute().AssertStatus();
        cerr << fooFunc.Name() << ": " << fooFunc.ErrorMessage() << endl;

        BAR_FUNC barFunc;
        barFunc.Copy(staticBuffer).Execute().AssertStatus();
        cerr << barFunc.Name() << ": " << barFunc.ErrorMessage() << endl;
    }

    cerr << "Dynamic code generation" << endl;
    void * dynamicBuffer;
    dynamicBuffer = MemAlloc(PI_FUNC::MAX_SIZE, MEM_READ_WRITE_EXEC);
    if (dynamicBuffer == 0) {Abort("MemAlloc failed");}

    {
        FOO_FUNC fooFunc;
        fooFunc.Copy(dynamicBuffer);
        if (!MemProtect(dynamicBuffer, PI_FUNC::MAX_SIZE, MEM_READ_EXEC)) {Abort("MemProtect failed");}
        for (int i = 0; i < 3; ++i)
        {
            fooFunc.Execute().AssertStatus();
            cerr << fooFunc.Name() << ": " << fooFunc.ErrorMessage() << endl;
        }
    }

    if (!MemProtect(dynamicBuffer, PI_FUNC::MAX_SIZE, MEM_READ_WRITE_EXEC)) {Abort("MemProtect failed");}

    {
        BAR_FUNC barFunc;
        barFunc.Copy(dynamicBuffer);
        if (!MemProtect(dynamicBuffer, PI_FUNC::MAX_SIZE, MEM_READ_EXEC)) {Abort("MemProtect failed");}
        for (int i = 0; i < 3; ++i)
        {
            barFunc.Execute().AssertStatus();
            cerr << barFunc.Name() << ": " << barFunc.ErrorMessage() << endl;
        }
    }

    return 0;
}

/* ===================================================================== */
/* eof */
/* ===================================================================== */
